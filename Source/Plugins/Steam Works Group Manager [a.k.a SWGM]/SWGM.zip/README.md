# [CORE] Steam Works Group Manager [a.k.a SWGM]

This plugin provides additional features for other plugin. Working as core.

It can check player is in steam group.

# Commands
sm_swgm_check — force check all connected players.


# Cvars
sm_swgm_groupid — identifier of your steam group.

sm_swgm_timer — interval beetwen checks.

# Requirements:
Sourcemod 1.8+

Latest version of SteamWorks.

# Instalation:
Put these files into your sourcemod folder.

Open group administration panel and copy identifier then set it in swgm_groupid. (Don't forget cfg/sourcemod/swgm.cfg)
