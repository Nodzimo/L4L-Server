# Description | 內容
Thirdpersonshoulder Shotgun Sound Fix

* Apply to | 適用於
	```
	L4D1
	L4D2
	```

* <details><summary>Changelog | 版本日誌</summary>

	* v1.2 (2022-11-29)
		* Combine windows and linux
		* Remake Code
	* v1.1
		* [Original Plugin By MasterMind420](https://forums.alliedmods.net/showthread.php?t=298776)
</details>

* Require | 必要安裝
	1. [ThirdPersonShoulder_Detect](https://forums.alliedmods.net/showthread.php?t=298649)

- - - -
# 中文說明
修復第三人稱下，散彈槍射擊沒有槍聲

* 原理
	* 原本的第三人稱下，玩家發射散彈槍沒有聲音
	* 惡靈勢力啟動第三人稱還有很多十年來從沒有修過的Bug，包括雷射光看不見、射擊失準、手電筒位置不同、狙擊鏡縮圖問題等
		* 要如何修復不如問Valve何時數3
	